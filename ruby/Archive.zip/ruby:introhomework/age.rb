puts 'What is your age?'
input = gets.chomp.to_i
str1 = "Your age on"
str2 = "would be"

puts "Your age in seconds is #{input * 31536000}"
puts str1 + " Mercury would be #{input * 4.16}"
puts str1 + " Venus would be #{input * 1.6}"
puts str1 + " Mars would be #{input * 0.5}"
puts str1 + " Jupiter would be #{input * 0.08}"
puts str1 + " Saturn would be #{input * 0.03}"
puts str1 + " Uranus would be #{input * 0.012}"
puts str1 + " Neptune would be #{input * 0.006}"
puts str1 + " Pluto would be #{input * 0.004}"
