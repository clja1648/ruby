puts 'Pick a number.'
input = gets.chomp.to_i
puts 'Pick another number.'
input2 = gets.chomp.to_i

puts "Sum is #{input += input2}"
puts "Difference is #{input -= input2}"
puts "Product is #{input *= input2}"
puts "Quotient is #{input /= input2}"
puts "The Modulus is #{input %= input2}"
