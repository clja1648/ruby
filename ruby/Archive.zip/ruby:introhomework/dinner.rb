puts "How much did your dinner at Salsa Azteca cost?"
input = gets.chomp
input2 = input.to_f
input3 = 0.18

puts input2 * .18
 
