puts 'What is you favorite crayola crayon color?'
input = gets.chomp.upcase.reverse
puts input
