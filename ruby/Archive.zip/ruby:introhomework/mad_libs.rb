#verb, plural noun, adjective, preposition, geographical feature, object, number
puts "Give me a verb."
verb = gets.chomp

puts "Give me the same verb in present tense."
verbing = gets.chomp

puts "Give me a plural noun."
nouns = gets.chomp

puts "Give me an adjective."
adjective = gets.chomp

puts "Give me a number."
number = gets.chomp

puts "Give me a preposition."
preposition = gets.chomp

puts "Give me a geographical feature."
feature = gets.chomp

puts "Give me another present tense verb."
verbing2 = gets.chomp

puts "Give me an object."
object = gets.chomp

puts "Now give me another number."
number2 = gets.chomp

puts ""
puts "I have to #{verb} to work every morning."
puts ""
puts "This morning while I was #{verbing} to work, I got to thinking about #{nouns}."
puts ""
puts "But I wasn't thinking about just any old #{nouns}, I was thinking about #{adjective} #{nouns}."
puts ""
puts "Then out of no where I noticed that there were #{number} #{nouns} #{preposition} the road."
puts ""
puts "Further down the road, out of no where I noticed a #{feature} on the horizon!"
puts ""
puts "I decided to play hooky from work, and go take a closer look at the #{feature}."
puts ""
puts "As i approached the #{feature}, I saw #{number2} huge #{object}(s) #{verbing2} over the #{feature}!"
puts ""
puts "Then I woke up, and realized it was all a dream."
puts ""
