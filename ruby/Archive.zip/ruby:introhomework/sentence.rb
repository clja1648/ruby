puts 'Enter a sentence.'
input = gets.chomp

puts 'Now choose your favorite word in that sentence.'
input2 = gets.chomp

#This returns the index
puts input.index(input2)
