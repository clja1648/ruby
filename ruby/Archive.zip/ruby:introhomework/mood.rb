puts 'What is you mood today?'
input = gets.chomp

puts input.length
puts "meow#{input}"
